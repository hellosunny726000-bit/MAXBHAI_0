MAXBHAI_07 Landing Page

FILES
- index.html: responsive landing page
- assets/maxbhai07-logo.jpeg: your supplied MAXBHAI_07 logo image

BEFORE PUBLISHING
1. Open index.html in a text editor.
2. Search for: const telegramInviteUrl = '';
3. Put your real public Telegram invite URL between the quotes, e.g. https://t.me/yourchannel
4. Save the file and upload index.html plus the assets folder to your GitHub repository.

For GitHub Pages: repository Settings -> Pages -> Deploy from a branch -> select main and / (root) -> Save.
The page uses no external libraries.
